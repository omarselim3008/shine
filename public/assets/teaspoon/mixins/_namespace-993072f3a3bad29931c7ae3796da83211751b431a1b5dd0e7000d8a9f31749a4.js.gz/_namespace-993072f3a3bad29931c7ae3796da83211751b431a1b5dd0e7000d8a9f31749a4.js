(function() {
  Teaspoon.Mixins || (Teaspoon.Mixins = {});

}).call(this);
